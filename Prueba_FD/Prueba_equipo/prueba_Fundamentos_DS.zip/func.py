#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
File: func.py
Author: Daniel Mardones
Email: daniel[dot]mardones[dot]s[at]gmail[dot]com
Github: https://github.com/Denniels
Description: Funciones para prueba modulo DataSciens
"""

#import argparse
#import time
#import os
#from collections import Counter
#import math
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
#import scipy.stats as stats
import seaborn as sns
#from scipy.stats import norm
#from scipy.stats import t
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score
import warnings
warnings.filterwarnings(action="ignore")
colors = ["tomato", "darkgoldenrod", "limegreen", "dodgerblue", "sienna", "slategray"]

def summary_drop(data):

    """Funcion que entrega un summary de un dataframe completo.
    Args:
        data (DataFrame): Conjunto de datos
    Returns:
        pd.DataFrame: con todas las variables del df
    """
    tipos = pd.DataFrame({'tipo': data.dtypes},index=data.columns)
    na = pd.DataFrame({'nulos': data.isna().sum()}, index=data.columns)
    na_prop = pd.DataFrame({'porc_nulos':data.isna().sum()/data.shape[0]}, index=data.columns)
    ceros = pd.DataFrame({'ceros':[data.loc[data[col]==0,col].shape[0] for col in data.columns]}, index= data.columns)
    ceros_prop = pd.DataFrame({'porc_ceros':[data.loc[data[col]==0,col].shape[0]/data.shape[0] for col in data.columns]}, index= data.columns)
    summary = data.describe(include='all').T

    summary['dist_IQR'] = summary['75%'] - summary['25%']
    summary['limit_inf'] = summary['25%'] - summary['dist_IQR']*1.5
    summary['limit_sup'] = summary['75%'] + summary['dist_IQR']*1.5

    summary['outliers'] = data.apply(lambda x: sum(np.where((x<summary['limit_inf'][x.name]) | (x>summary['limit_sup'][x.name]),1 ,0)) if x.name in summary['limit_inf'].dropna().index else 0)


    return pd.concat([tipos, na, na_prop, ceros, ceros_prop, summary], axis=1).sort_values('tipo')

def form_model(df, var_obj):
    """Modelo logit con todos sus atributos.
    Args:
        df (dataframe): Conjunto de datos
        var_obj (string): variable objetivo
    Returns:
        string: formula del modelo
    """
    base_formula = f'{var_obj} ~ '
    for col in df.columns:
        if col != var_obj:
            base_formula += f'{col} + '
    return base_formula[:-3]

def predict(df, var_obj):
        """Función que automatiza las predicciones por LogisticRegression.

        Args:
                df (dataframe): dataframe con todas las variables a introducir 
                en el modelo, incluida la V.O.
                var_obj (str): variable objetivo

        Returns:
                array: vector de prueba y vector de predicciones
        """
        # separando matriz de atributos de vector objetivo
        # utilizamos dataframe con variables significativas
        mat_atr = df.drop(var_obj, axis=1)
        vec_obj = df[var_obj]
        # split de conjuntos de entrenamiento vs prueba
        X_train, X_test, y_train, y_test = train_test_split(mat_atr, vec_obj, test_size = .33, random_state = 15820)
        # estandarizamos conjunto de entrenamiento
        X_train_std = StandardScaler().fit_transform(X_train)
        X_test_std = StandardScaler().fit_transform(X_test)
        # ajustamos modelo sin alterar hiperparámetros
        modelo_x =  LogisticRegression().fit(X_train_std, y_train)
        # prediccion de clases y probabilidad
        y_hat = modelo_x.predict(X_test_std)
        return modelo_x, y_test, y_hat

def report_scores(y_predict, y_validate):
    """Calcula el error cuadrático medio y el r2 score entre dos vectores. 
    El primero, el vector de valores predecidos por el
    conjunto de prueba, y el segundo, el vector objetivo original.

    Args:
        y_predict (vector): vector de valores predecidos
        y_validate (vector): vector de valores verdaderos
    """
    mse = mean_squared_error(y_validate, y_predict)
    r2 = r2_score(y_validate, y_predict).round(2)
    print(f'Error cuadrático medio: {mse}')
    print(f'R2: {r2}')

def dist_box(data):
    """Funcion que imprime grafico de las distribuciones de un 
    dataframe completo.
    Args:
        data (DataFrame): Conjunto de datos
    Returns:
        distplots: con todas las variables del df
    """
    Name=data.name.upper()
    fig,(ax_box,ax_dis) = plt.subplots(nrows=2,sharex=True,gridspec_kw = {"height_ratios": (.25, .75)},figsize=(8, 5))
    mean=data.mean()
    median=data.median()
    mode=data.mode().tolist()[0]
    sns.set_theme(style="white")
    fig.suptitle("Distribucion para "+ Name  , fontsize=18, fontweight='bold')
    sns.boxplot(x=data,showmeans=True, orient='h',color="tan",ax=ax_box)
    ax_box.set(xlabel='')

    sns.despine(top=True,right=True,left=True) 
    sns.distplot(data,kde=False,color='red',ax=ax_dis)
    ax_dis.axvline(mean, color='r', linestyle='--',linewidth=2)
    ax_dis.axvline(median, color='g', linestyle='-',linewidth=2)
    plt.legend({'Media':mean,'Mediana':median})